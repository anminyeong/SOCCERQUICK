package com.example.soccerquick2.MyClub;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soccerquick2.R;

public class club_info_apply_list extends BaseAdapter{
    String [] result;
    String [] result2;
    String [] result3;
    Context context;

    private static LayoutInflater inflater=null;
    public club_info_apply_list(Context context, String[] num, String[] memberlist, String[] kakaolist) {
        // TODO Auto-generated constructor stub
        this.context=context;

        result3 = num;
        result=memberlist;
        result2 = kakaolist;

        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView num;
        TextView nick;
        TextView kakao;
        Button agree;
        Button deny;

    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.activity_club_info_list, null);

        holder.num = (TextView) rowView.findViewById(R.id.num);
        holder.nick=(TextView) rowView.findViewById(R.id.nick);
        holder.kakao =(TextView) rowView.findViewById(R.id.kakao);

        holder.agree = (Button) rowView.findViewById(R.id.button6);
        holder.deny = (Button) rowView.findViewById(R.id.button9);

        holder.num.setText(result3[position]);
        holder.nick.setText(result[position]);
        holder.kakao.setText(result2[position]);


        holder.agree.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, result[position] + "님이 수락되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        holder.deny.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, result[position]+ "님이 거절되었습니다.",Toast.LENGTH_SHORT).show();
            }
        });


        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_SHORT).show();
            }
        });
        return rowView;
    }

}