package com.example.soccerquick2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class login extends Activity {

    EditText email, password;
    String email_str, password_str;
    int checked;
    Boolean login_soccess = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.pwd);


        if(MusicService.player == null) {
            MusicService.player = MediaPlayer.create(this, R.raw.music1);
            MusicService.player.setLooping(false);
            Uri music = Uri.parse("android.resource://" + getPackageName() + "/raw/music1");
            playSong(music);
        }
    }

    public void playSong(Uri songPath)
    {
        try{
            MusicService.selectedUri = songPath;
            Intent service = new Intent();
            service.putExtra("songPath",songPath);
            startService(service);
            play(null);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void play(View view)
    {
        if(MusicService.selectedUri != null) {
            MusicService.player.reset();
            MusicService.player = MediaPlayer.create(this, MusicService.selectedUri);
        }
        MusicService.player.start();

        startService(new Intent(this, MusicService.class));

    }

    public void user_join(View v){
        Intent intent = new Intent(getApplicationContext(),join.class);
        startActivity(intent);

    }

    public void user_login(View v) {
        email_str = email.getText().toString();
        password_str = password.getText().toString();



            class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
                JSONObject list = null;


                protected void onPreExecute() {

                }

                @Override
                protected Integer doInBackground(Integer... arg0) {
                    // TODO Auto-generated method stub
                    Log.e("test", "@");
                    HttpURLConnection urlConn = null;
                    OutputStream outStream = null;
                    BufferedReader jsonStreamData = null;
                    BufferedWriter writer = null;
                    Log.e("test", "@");

                    try {

                        Log.e("test", "@");
                        urlConn = getHttpURLConnection("http://52.193.2.122:3001/login/"+email_str+"/"+password_str, "GET", getApplicationContext());
                        int response = urlConn.getResponseCode();   //받을 권리를 받음.
                        if (response >= 200 && response < 300)      //서버에서 응답
                            jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
                        else {
                            Log.e("MynoteCall", "jsonSteamData Not Found");
                            return null;
                        }
                        String line = "";
                        StringBuilder buf = new StringBuilder();
                        while ((line = jsonStreamData.readLine()) != null) {
                            Log.i("lineResult", line.toString());
                            buf.append(line);
                        }
                        jsonStreamData.close();
                        list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리
                        Log.i("requset", buf.toString());

                        checked = list.getInt("check");

//                        JSONArray title_array = new JSONArray(list.getString("title"));
//                        JSONArray content_array = new JSONArray(list.getString("content"));


//                        for(int i=0; i<title_array.length(); i++){
//                            prgmNameList[i] = title_array.getString(i);
//                            subtitle[i] = content_array.getString(i);
//                        }
//                        Log.i("6565656", prgmNameList[2]);
//                        Log.i("index",subtitle[2]);
//                        Log.i("title", list.getString("title"));

                    } catch (IOException ioe) {
                        Log.e("MynoteCall", "IOException");
                        ioe.getStackTrace();
                    } catch (JSONException jse) {
                        Log.i("MainViewPagerJsonerror", jse.toString());
                        jse.getStackTrace();
                    }
                    return null;
                }

                protected void onPostExecute(Integer a) {
//                    lv = (ListView) findViewById(R.id.listView);
//                    lv.setAdapter(new CustomAdapter(getApplicationContext(), prgmNameList, prgmImages, subtitle));
//                    Log.e("test", "@");

                    if(checked == 1){
                        Toast.makeText(getApplicationContext(), email_str+"님 환영합니다.", Toast.LENGTH_LONG).show();

                        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
                        SharedPreferences.Editor editor = pref.edit();
                        editor.putString("id", email_str);
                        editor.commit();


                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(getApplicationContext(), "아이디와 비밀번호를 다시 확인해주세요.", Toast.LENGTH_LONG).show();
                    }
                }
            }
            BackgroundTask task = new BackgroundTask();
            task.execute(null, null, null);

    }



    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
