package com.example.soccerquick2.MyClub;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.soccerquick2.Board.CustomAdapter;
import com.example.soccerquick2.Board.board_main;
import com.example.soccerquick2.Fragment_Club.club_list;
import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.Match.match_list;
import com.example.soccerquick2.user_info;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

//import static com.example.soccerquick2.MyClub.club_info_list_custom.getHttpURLConnection;

public class club_info extends Activity {

    ListView lv1;
    ListView lv2;
    Context context;

    ArrayList prgmName;

    String member_id;
    int my_club_img;
    String my_club_title, my_club_content;

    ListView lv;



    public static String [] num={"1","2","3","4","5","6","7","8","9"};
    public static String [] memberlist={"회원1","회원2","회원3","회원4","회원5","회원6","회원7","회원8","회원9"};
    public static String [] kakaolist ={"카톡1","카톡2","카톡3","카톡4","카톡5","카톡6","카톡7","카톡8","카톡9"};

    public static String [] num2={"1","2","3"};
    public static String [] apply_member={"회원1","회원2","회원3"};
    public static String [] apply_kakao ={"카톡1","카톡2","카톡3"};

    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정","로그아웃"};
    private ListView lvNavList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_info);

        context = this;

        lv1 = (ListView) findViewById(R.id.listView5);
        lv1.setAdapter(new club_info_list(this, num, memberlist, kakaolist));

        lv2 = (ListView) findViewById(R.id.listView6);
        lv2.setAdapter(new club_info_apply_list(this, num2, apply_member, apply_kakao));

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());


        //getIntent로 클럽이름을 받아옴
        Intent intent = getIntent();
        String my_club_title = intent.getExtras().getString("club_name");
        int my_club_img =  intent.getExtras().getInt("club_img");
        String my_club_content = intent.getExtras().getString("club_content");



        ImageView img = (ImageView)findViewById(R.id.imageView2);
        img.setImageResource(my_club_img);

        TextView name = (TextView)findViewById(R.id.textView15);
        name.setText(my_club_title);

        TextView content = (TextView)findViewById(R.id.textView16);
        content.setText(my_club_content);


//        Snackbar snackbar = Snackbar.make(
//                name,
//                my_club_title+"에 오신것을 환영합니다.",
//                Snackbar.LENGTH_LONG);
//        snackbar.setActionTextColor(Color.RED);
//        View snackbarView = snackbar.getView();
//        snackbarView.setBackgroundColor(Color.WHITE);


        SpannableStringBuilder snackbarText = new SpannableStringBuilder();

        int boldStart = snackbarText.length();
        snackbarText.append(my_club_title);
        snackbarText.setSpan(new ForegroundColorSpan(0xFFFF0000), boldStart, snackbarText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        snackbarText.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), boldStart, snackbarText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        snackbarText.append(" 에 오신것을 환영합니다.");

        Snackbar.make(name, snackbarText, Snackbar.LENGTH_LONG).show();



//
//        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
//        member_id = pref.getString("id", "");
//
//        class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
//            JSONObject list = null;
//
//            protected void onPreExecute() {
//
//
//            }
//
//            @Override
//            protected Integer doInBackground(Integer... arg0) {
//                // TODO Auto-generated method stub
//                Log.e("test", "@");
//                HttpURLConnection urlConn = null;
//                OutputStream outStream = null;
//                BufferedReader jsonStreamData = null;
//                BufferedWriter writer = null;
//                Log.e("test", "@");
//
//                try {
//
//                    Log.e("test", "@");
//                    //첫번째 부분
//                    urlConn = getHttpURLConnection("http://52.193.2.122:3001/clubdetail"+member_id+club_name, "GET", getApplicationContext());
//                    int response = urlConn.getResponseCode();   //받을 권리를 받음.
//                    if (response >= 200 && response < 300)      //서버에서 응답
//                        jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
//                    else {
//                        Log.e("MynoteCall", "jsonSteamData Not Found");
//                        return null;
//                    }
//                    String line = "";
//                    StringBuilder buf = new StringBuilder();
//                    while ((line = jsonStreamData.readLine()) != null) {
//                        Log.i("lineResult", line.toString());
//                        buf.append(line);
//                    }
//                    list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리
//                    //JSONObject title = list.getJSONObject("title");
//                    //여기서 값을 처리
//
//
//                    JSONArray img_array = new JSONArray(list.getString("img"));
//                    JSONArray title_array = new JSONArray(list.getString("title"));
//                    JSONArray content_array = new JSONArray(list.getString("content"));
//
//
//
//
//
////                    for(int i=0; i<title_array.length(); i++){
////                        prgmNameList[i] = title_array.getString(i);
////                        subtitle[i] = content_array.getString(i);
////                    }
////                    Log.i("6565656", prgmNameList[2]);
////                    Log.i("index",subtitle[2]);
////                    Log.i("title", list.getString("title"));
//
//                } catch (IOException ioe) {
//                    Log.e("MynoteCall", "IOException");
//                    ioe.getStackTrace();
//                } catch (JSONException jse) {
//                    Log.i("MainViewPagerJsonerror", jse.toString());
//                    jse.getStackTrace();
//                }
//                return null;
//            }
//
//            protected void onPostExecute(Integer a) {
//
//            }
//        }
//        BackgroundTask task = new BackgroundTask();
//        task.execute(null, null, null);




















    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), match_list.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }



    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }




}