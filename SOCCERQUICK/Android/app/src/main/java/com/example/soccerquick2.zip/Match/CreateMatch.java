package com.example.soccerquick2.Match;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.soccerquick2.Board.board_main;
import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.user_info;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by YSH on 2015-11-13.
 */
public class CreateMatch extends Activity {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat startFormat = new SimpleDateFormat("kk");
    SimpleDateFormat endFormat = new SimpleDateFormat("kk");

    private String team , local, people, title, content, match_date; //게시글 쓸때 넘겨줄 거
    int start,end;

    SimpleDateFormat curDate = new SimpleDateFormat("yyyy/MM/dd"); //현재시간
    String cur_date = curDate.format(new Date(System.currentTimeMillis()));
    Button btn;
    Calendar dateTime = Calendar.getInstance();
    Calendar startTime = Calendar.getInstance();
    Calendar endTime = Calendar.getInstance();
    public String[] team_array = {"오프라인"}; //팀스피너 사용할때 쓰임
    public static ArrayList<String> team_spinner = new ArrayList<String>();
    //id 받아오기
    String member_id;
    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정", "로그아웃"};
    private ListView lvNavList;

    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            dateTime.set(Calendar.YEAR, year);
            dateTime.set(Calendar.MONTH, monthOfYear);
            dateTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateDate();
        }
    };

    TimePickerDialog.OnTimeSetListener st = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            startTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
            startTime.set(Calendar.MINUTE, minute);
            updateStart();
        }
    };
    TimePickerDialog.OnTimeSetListener et = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            endTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
            endTime.set(Calendar.MINUTE, minute);
            updateEnd();
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create);
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        member_id = pref.getString("id", "");
        Button btn = (Button) findViewById(R.id.dateBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(CreateMatch.this, d, dateTime.get(Calendar.YEAR),
                        dateTime.get(Calendar.MONTH), dateTime.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        btn = (Button) findViewById(R.id.startBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(CreateMatch.this, st, startTime.get(Calendar.HOUR_OF_DAY),
                        startTime.get(Calendar.MINUTE), true).show();
            }
        });

        btn = (Button) findViewById(R.id.endBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(CreateMatch.this, et, endTime.get(Calendar.HOUR_OF_DAY),
                        endTime.get(Calendar.MINUTE), true).show();
            }
        });

        Spinner spinner1 = (Spinner) findViewById(R.id.spinner1);
        final ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.people_array, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                people = parent.getItemAtPosition(position).toString(); //인원선택
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);
        final ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.local_array, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                local = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        //취소버튼
        btn = (Button) findViewById(R.id.cancel);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), match_list.class);
                startActivity(intent);
            }
        });

        final TextView tv_title = (TextView)findViewById(R.id.match_title); //제목 받아올 text
        final TextView tv_content = (TextView)findViewById(R.id.match_content); //내용 받아올 text
        btn = (Button)findViewById(R.id.createBtn); //매치생성버튼
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("test", "@");
                //post 부분
                class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
                    protected void onPreExecute() {
                        title = tv_title.getText().toString();
                        content = tv_content.getText().toString();
                    }

                    @Override
                    protected Integer doInBackground(Integer... arg0) {
                        // TODO Auto-generated method stub
                        Log.e("test","@");
                        HttpURLConnection urlConn = null;
                        OutputStream outStream = null;

                        BufferedWriter writer = null;
                        Log.e("test", "@");

                        try {
                            //jsonText/
                            JSONObject jsonBody = new JSONObject();
                            jsonBody.put("title", title);
                            jsonBody.put("content", content);
                            jsonBody.put("people", people);
                            jsonBody.put("local", local);
                            jsonBody.put("team", team);
                            jsonBody.put("match_date", match_date);
                            jsonBody.put("cur_date", cur_date);
                            jsonBody.put("match_start", start);
                            jsonBody.put("match_end", end);

                            Log.i("jsonBody", jsonBody.toString());
                            Log.e("test", "@");
                            urlConn = getHttpURLConnection("http://52.69.253.198:3001/match/upload/test/"+team, "POST", getApplicationContext());
                            //int response = urlConn.getResponseCode();
                            //String reString = urlConn.getRequestMethod();
                            //urlConn.getRequestProperty("application/json");
                            outStream = urlConn.getOutputStream();
                            Log.e("test","@");
                            writer = new BufferedWriter(new OutputStreamWriter(outStream,"UTF-8"));
                            StringBuilder buf = new StringBuilder();
                            buf.append(jsonBody.toString());
                            writer.write(buf.toString());

                            Log.i("OutStream", outStream.toString());
                            writer.flush();
                            Log.i("inputStream", urlConn.getResponseCode() + "");

                            InputStream inputstream = urlConn.getInputStream();

                            writer.close();
                            outStream.close();

                        } catch (JSONException joe) {
                            Log.e("Group_Page_PostResult", "IOException");
                            joe.getStackTrace();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } finally {
                            if(urlConn != null){

                                urlConn.disconnect();
                            }
                        }
                        return null;
                    }
                    protected void onPostExecute(Integer a) {
                        Toast.makeText(getApplicationContext(), "글쓰기성공", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), match_list.class);
                        startActivity(intent);
                    }
                }new BackgroundTask().execute();
            }
        });

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());


        //get 부분
        class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
            JSONObject list;

            @Override
            protected Integer doInBackground(Integer... params) {
                Log.e("test", "@");
                HttpURLConnection urlConn = null;
                OutputStream outStream = null;
                BufferedReader jsonStreamData = null;
                BufferedWriter writer = null;
                Log.e("test", "@");

                try {

                    Log.e("test", "@");
                    //첫번째 부분
                    urlConn = getHttpURLConnection("http://52.69.253.198:3001/clubinfo/"+member_id, "GET", getApplicationContext());
                    int response = urlConn.getResponseCode();   //받을 권리를 받음.
                    if (response >= 200 && response < 300)      //서버에서 응답
                        jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
                    else {
                        Log.e("MynoteCall", "jsonSteamData Not Found");
                        return null;
                    }
                    String line = "";
                    StringBuilder buf = new StringBuilder();
                    while ((line = jsonStreamData.readLine()) != null) {
                        Log.i("lineResult", line.toString());
                        buf.append(line);
                    }
                    list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리
                    //JSONObject title = list.getJSONObject("title");
                    //여기서 값을 처리

                    JSONArray Jteam_array = new JSONArray((list.getString("team"))); //team 스피너 받아올 배열

                    for (int j = 0; j < Jteam_array.length(); j++) { //팀 받아오기 반복문
                        team_array[j + 1] = Jteam_array.getString(j);
                    }

                    Log.i("6565656", team_array[1]);
                    Log.i("title", list.getString("title"));

                } catch (IOException ioe) {
                    Log.e("MynoteCall", "IOException");
                    ioe.getStackTrace();
                } catch (JSONException jse) {
                    Log.i("MainViewPagerJsonerror", jse.toString());
                    jse.getStackTrace();
                }
                return null;
            }

            protected void onPostExecute(Integer a) {
                //팀 스피너
                Spinner spinner0 = (Spinner) findViewById(R.id.spinner0);
                for (int i = 0; i < team_array.length; i++) {
                    team_spinner.add(team_array[i]);
                }
                ArrayAdapter<String> adapter0 = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, team_spinner);
                adapter0.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner0.setAdapter(adapter0);
                spinner0.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        team = parent.getItemAtPosition(position).toString(); //팀선택
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

                BackgroundTask task = new BackgroundTask();
                task.execute(null, null, null);
            }
        }
    }

    private void updateDate() {
        btn = (Button) findViewById(R.id.dateBtn);
        btn.setText(dateFormat.format(dateTime.getTime()));
        match_date = dateFormat.format(dateTime.getTime());
    }

    private void updateStart() {
        btn = (Button) findViewById(R.id.startBtn);
        btn.setText(startFormat.format(startTime.getTime()));
        start = Integer.parseInt(startFormat.format(startTime.getTime()));
    }

    private void updateEnd() {
        btn = (Button) findViewById(R.id.endBtn);
        btn.setText(endFormat.format(endTime.getTime()));
        end = Integer.parseInt(endFormat.format(endTime.getTime()));
    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), match_list.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }
    //두번째 부분
    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }
}