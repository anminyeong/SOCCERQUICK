package com.example.soccerquick2.MyClub;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.soccerquick2.Board.CustomAdapter;
import com.example.soccerquick2.Board.board_main;
import com.example.soccerquick2.Board.board_write;
import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.Match.match_list;
import com.example.soccerquick2.user_info;

import java.util.ArrayList;

public class club_board extends Activity {

    ListView lv1;
    Context context;

    ArrayList prgmName;
    public static int [] prgmImages1={R.drawable.images,R.drawable.images1,R.drawable.images,R.drawable.images,R.drawable.images,R.drawable.images,R.drawable.images,R.drawable.images,R.drawable.images};
    public static String [] prgmNameList1={"클럽게시판1","게시판2","게시판3","게시판4","게시판5","게시판6","게시판7","게시판8","게시판9"};
    public static String [] subtitle1 ={"클럽내용1","내용2","내용3","내용4","내용5","내용6","내용7","내용8","내용9"};

    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정","로그아웃"};
    private ListView lvNavList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_board);

        Spinner spinner = (Spinner) findViewById(R.id.spinner4);
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.club_list,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                Toast.makeText(adapterView.getContext(), " 선택한 글머리는 " + adapterView.getItemAtPosition(i).toString() + " 입니다!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        context=this;

        lv1=(ListView) findViewById(R.id.listView4);
        lv1.setAdapter(new CustomAdapter(this, prgmNameList1, prgmImages1, subtitle1));

        Button club_board_write = (Button)findViewById(R.id.button12);

        club_board_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),board_write.class);
                startActivity(intent);
            }
        });

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());
    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), match_list.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }

}
