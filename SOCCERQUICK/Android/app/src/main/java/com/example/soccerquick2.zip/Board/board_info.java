package com.example.soccerquick2.Board;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.Match.match_list;
import com.example.soccerquick2.user_info;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class board_info extends Activity {
    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정","로그아웃"};
    private ListView lvNavList;
    private String member_id, board_user_id, board, title, date, content, header;
    private TextView board_title,board_content, board_date, board_header;
    private Button del, mod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board_info);

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        member_id = pref.getString("id", "");

        Button btn = (Button)findViewById(R.id.replyBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(board_info.this, "댓글등록", Toast.LENGTH_SHORT).show();
            }
        });

        btn = (Button)findViewById(R.id.backBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),board_main.class);
                startActivity(intent);
            }
        });

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());

        //get 부분
        class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
            JSONObject list;

            @Override
            protected Integer doInBackground(Integer... params) {
                Log.e("test", "@");
                HttpURLConnection urlConn = null;
                OutputStream outStream = null;
                BufferedReader jsonStreamData = null;
                BufferedWriter writer = null;
                Log.e("test", "@");

                try {

                    Log.e("test", "@");
                    //첫번째 부분
                    urlConn = getHttpURLConnection("http://52.69.253.198:3001/board/detail/"+board, "POST", getApplicationContext());
                    int response = urlConn.getResponseCode();   //받을 권리를 받음.
                    if (response >= 200 && response < 300)      //서버에서 응답
                        jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
                    else {
                        Log.e("MynoteCall", "jsonSteamData Not Found");
                        return null;
                    }
                    String line = "";
                    StringBuilder buf = new StringBuilder();
                    while ((line = jsonStreamData.readLine()) != null) {
                        Log.i("lineResult", line.toString());
                        buf.append(line);
                    }
                    list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리

                    board_user_id = list.getString("member_id");
                    title = list.getString("title");
                    content = list.getString("content");
                    header = list.getString("header");
                    board = list.getString("board_id");
                    date = list.getString("date");

                    Log.i("get", "여기까지 받아왔을까");

                } catch (IOException ioe) {
                    Log.e("MynoteCall", "IOException");
                    ioe.getStackTrace();
                } catch (JSONException jse) {
                    Log.i("MainViewPagerJsonerror", jse.toString());
                    jse.getStackTrace();
                }
                return null;
            }
            protected void onPostExecute(Integer a) {
                //팀 스피너
                board_header = (TextView)findViewById(R.id.header);
                board_header.setText(header);
                board_date = (TextView)findViewById(R.id.date);
                board_date.setText(date);
                board_title = (TextView)findViewById(R.id.title);
                board_title.setText(title);
                board_content = (TextView)findViewById(R.id.content);
                board_content.setText(content);
                del = (Button)findViewById(R.id.delBtn);
                mod = (Button)findViewById(R.id.modifyBtn);
                if(member_id==board_user_id){
                    del.setVisibility(View.VISIBLE);
                    mod.setVisibility(View.VISIBLE);
                }
                BackgroundTask task = new BackgroundTask();
                task.execute(null, null, null);
            }
        }
    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), match_list.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }

    //두번째 부분
    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }
}
