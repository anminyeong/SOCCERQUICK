package com.example.soccerquick2.ground;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.soccerquick2.Board.board_main;
import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.MainActivity;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.user_info;

/**
 * Created by YSH on 2015-11-20.
 */
public class Create_ground extends AppCompatActivity {
    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정","로그아웃"};
    private ListView lvNavList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_ground);
        Button btn = (Button)findViewById(R.id.btnCreate);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "구장등록", Toast.LENGTH_LONG).show();
            }
        });
        btn = (Button)findViewById(R.id.btnCancle);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Ground.class);
                startActivity(intent);
            }
        });

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());
    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }
}
