package com.example.soccerquick2.Match;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soccerquick2.R;

import java.util.ArrayList;
import java.util.List;

public class MatchAdapter extends BaseAdapter {
    //List<String> result_logo = new ArrayList<String>();
    List<Integer> result_id = new ArrayList<Integer>();
    List<String> result_title = new ArrayList<String>();
    List<String> result_local = new ArrayList<String>();
    List<String> result_people = new ArrayList<String>();
    List<String> result_date = new ArrayList<String>();
    List<Integer> result_start = new ArrayList<Integer>();
    List<Integer> result_end = new ArrayList<Integer>();
    List<Integer> result_match = new ArrayList<Integer>();
    Context context;
    int[] imageId;
    private static LayoutInflater inflater = null;

    public MatchAdapter(Context Activity, List<Integer> match_id, List<Integer> user_id, List<String> title, List<String> people, List<String> local, List<String> date, List<Integer> start, List<Integer> end, int[] logo) {
        // TODO Auto-generated constructor stub
        result_match = match_id;
        imageId = logo;
        result_id = user_id;
        result_title = title;
        result_local = local;
        result_people = people;
        result_date = date;
        result_start = start;
        result_end = end;
        context = Activity;
        //imageId = prgmImages;
        inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result_id.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder {
        TextView tv, tv2, tv3, tv4, tv5, tv6, tv7;
        ImageView img;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder = new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.match_list, null);
        holder.tv = (TextView) rowView.findViewById(R.id.title);
        holder.tv2 = (TextView) rowView.findViewById(R.id.id);
        holder.tv3 = (TextView) rowView.findViewById(R.id.people);
        holder.tv4 = (TextView) rowView.findViewById(R.id.local);
        holder.tv5 = (TextView) rowView.findViewById(R.id.date);
        holder.tv6 = (TextView) rowView.findViewById(R.id.start);
        holder.tv7 = (TextView) rowView.findViewById(R.id.end);
        holder.img = (ImageView) rowView.findViewById(R.id.imageView1);
        holder.tv.setText(result_title.get(position));
        holder.tv2.setText(result_id.get(position).toString());
        holder.tv3.setText(result_people.get(position));
        holder.tv4.setText(result_local.get(position));
        holder.tv5.setText(result_date.get(position));
        holder.tv6.setText(result_start.get(position).toString());
        holder.tv7.setText(result_end.get(position).toString());
        holder.img.setImageResource(imageId[position]);
        Button btn = (Button)rowView.findViewById(R.id.matchBtn);
        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Toast.makeText(context, "매치신청 푸시"+result_match.get(position).toString(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context,Match_info.class);
                intent.putExtra("match_id",result_match.get(position).toString());
                context.startActivity(intent);
            }
        });
        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Toast.makeText(context, "매치신청 푸시" ,Toast.LENGTH_SHORT).show();
            }
        });
        return rowView;
    }
}
