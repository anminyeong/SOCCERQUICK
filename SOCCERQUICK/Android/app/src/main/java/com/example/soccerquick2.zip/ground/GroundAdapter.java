package com.example.soccerquick2.ground;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soccerquick2.Board.board_info;
import com.example.soccerquick2.R;

/**
 * Created by YSH on 2015-11-19.
 */
public class GroundAdapter extends BaseAdapter {
    String[] result;
    String[] result2;
    String[] result3;
    Context context;
    int[] imageId;
    private static LayoutInflater inflater = null;

    public GroundAdapter(Context context, String[] court ,String[] prgmNameList, int[] prgmImages, String[] subtitle) {
        // TODO Auto-generated constructor stub
        result = prgmNameList;
        result2 = subtitle;
        result3 = court;
        this.context=context;
        imageId = prgmImages;
        inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder {
        TextView tv;
        TextView tv2;
        TextView tv3;
        ImageView img;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder = new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.ground_list, null);
        holder.tv = (TextView) rowView.findViewById(R.id.grd_local);
        holder.tv2 = (TextView) rowView.findViewById(R.id.grd_name);
        holder.tv3 = (TextView) rowView.findViewById(R.id.grd_court);
        holder.img = (ImageView) rowView.findViewById(R.id.imageView);
        holder.tv.setText(result[position]);
        holder.tv2.setText(result2[position]);
        holder.tv3.setText(result3[position]);
        holder.img.setImageResource(imageId[position]);
        Button btn = (Button)rowView.findViewById(R.id.grdBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(context, ground_schedule.class);
                context.startActivity(intent);

                Toast.makeText(context, "You Clicked " + result[position], Toast.LENGTH_SHORT).show();
            }
        });

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,ground_info.class);
                context.startActivity(intent);
            }
        });


        return rowView;
    }
}
