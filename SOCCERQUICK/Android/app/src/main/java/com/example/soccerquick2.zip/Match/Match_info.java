package com.example.soccerquick2.Match;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.soccerquick2.Board.board_main;
import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.user_info;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by YSH on 2015-11-19.
 */
public class Match_info extends AppCompatActivity {
    ListView lv;


    public static int[] prgmImages = {R.drawable.images, R.drawable.images1, R.drawable.images};

    List<String> kakao = new ArrayList<String>();
    List<String> user_id_array = new ArrayList<String>();

    Context context;
    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정","로그아웃"};
    private ListView lvNavList;
    String member_id, title, date, match_date,stadium, person, club, local, content, match_id;
    int start_time, end_time;
    TextView match_title, cur_date, date_match, match_stadium, match_person, user_id, match_club, match_local, match_start, match_end, match_content;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.match_info);
        Intent intent = getIntent();
        match_id = intent.getExtras().getString("match_id");
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        member_id = pref.getString("id", "");

        BackgroundTask task = new BackgroundTask();
        task.execute(null, null, null);
        context = this;

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());

    }


    //get
    class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
        JSONObject list = null;

        protected void onPreExecute() {
        }

        @Override
        protected Integer doInBackground(Integer... arg0) {
            // TODO Auto-generated method stub
            Log.e("test", "@");
            HttpURLConnection urlConn = null;
            OutputStream outStream = null;
            BufferedReader jsonStreamData = null;
            BufferedWriter writer = null;
            Log.e("test", "@");

            try {
                Log.e("test", "@");
                //첫번째 부분
                urlConn = getHttpURLConnection("http://52.193.2.122/match/detail/"+match_id, "GET", getApplicationContext());
                Log.e("test", "과연");
                int response = urlConn.getResponseCode();   //받을 권리를 받음.
                if (response >= 200 && response < 300)      //서버에서 응답
                    jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
                else {
                    Log.e("MynoteCall", "jsonSteamData Not Found");
                    return null;
                }
                String line = "";
                StringBuilder buf = new StringBuilder();
                while ((line = jsonStreamData.readLine()) != null) {
                    Log.i("lineResult", line.toString());
                    buf.append(line);
                }
                list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리

                //JSONArray logo_array = new JSONArray(list.getString("logo"));
                JSONArray array = new JSONArray(list.getString("match_info"));
                JSONObject task = new JSONObject(array.getString(0));
                member_id = task.getString("member_id");
                title = task.getString("title");
                date = task.getString("date");
                match_date = task.getString("match_date");
                start_time = task.getInt("start_time");
                end_time = task.getInt("end_time");
                person = task.getString("person");
                club = task.getString("club");
                local = task.getString("local");
                stadium = task.getString("stadium");
                content = task.getString("content");
                JSONArray id_array = new JSONArray(list.getString("member_id"));
                JSONArray kakao_array = new JSONArray(list.getString("kakao"));
                for(int i =0; i<id_array.length();i++){
                    kakao.add(kakao_array.getString(i));
                    user_id_array.add(id_array.getString(i));
                }

            } catch (IOException ioe) {
                Log.e("MynoteCall", "IOException");
                ioe.getStackTrace();
            } catch (JSONException jse) {
                Log.i("MainViewPagerJsonerror", jse.toString());
                jse.getStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Integer a) {
            //match_title, cur_date, date_match, match_stadium, match_person, user_id, match_club, match_local, match_start, match_end, match_content;
            match_title = (TextView)findViewById(R.id.title);
            match_title.setText(title);
            cur_date = (TextView)findViewById(R.id.cur_date);
            cur_date.setText(date);
            date_match = (TextView)findViewById(R.id.date);
            date_match.setText(match_date);
            match_stadium = (TextView)findViewById(R.id.stadium);
            match_stadium.setText(stadium);
            match_person = (TextView)findViewById(R.id.person);
            match_person.setText(person);
            user_id = (TextView)findViewById(R.id.member_id);
            user_id.setText(member_id);
            match_club = (TextView)findViewById(R.id.club);
            match_club.setText(club);
            match_local = (TextView)findViewById(R.id.local);
            match_local.setText(local);
            match_start = (TextView)findViewById(R.id.start);
            match_start.setText(Integer.toString(start_time));
            match_end = (TextView)findViewById(R.id.end);
            match_end.setText(Integer.toString(end_time));
            match_content = (TextView)findViewById(R.id.content);
            match_content.setText(content);
            lv = (ListView) findViewById(R.id.listView);
            lv.setAdapter(new ApplyAdapter(context, user_id_array ,kakao, prgmImages));
        }
    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), match_list.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }

    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }

}
