package com.example.soccerquick2.Fragment_Club;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.soccerquick2.Board.CustomAdapter;
import com.example.soccerquick2.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Fragment_Club_List extends Fragment {
    ListView lv;
    Context context;

   // public  int [] prgmImages = new int[100];
  // public  String [] prgmNameList = new String[100];
    //    public  String [] subtitle=new String[100];
//    public  String [] subtitle2=new String[100];
    List<Integer> prgmImages = new ArrayList<Integer>();
    List<String> prgmNameList = new ArrayList<String>();
    List<String> subtitle = new ArrayList<String>();
    List<String> subtitle2 = new ArrayList<String>();

//

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.activity_join_club, container, false);

        context=getActivity();

        class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
            JSONObject list = null;

            protected void onPreExecute() {

            }

            @Override
            protected Integer doInBackground(Integer... arg0) {
                // TODO Auto-generated method stub
                Log.e("test", "@");
                HttpURLConnection urlConn = null;
                OutputStream outStream = null;
                BufferedReader jsonStreamData = null;
                BufferedWriter writer = null;
                Log.e("test", "@");

                try {

                    Log.e("test", "@");
                    //첫번째 부분
                    urlConn = getHttpURLConnection("http://52.193.2.122:3001/clublist", "GET", getActivity());
                    int response = urlConn.getResponseCode();   //받을 권리를 받음.
                    if (response >= 200 && response < 300)      //서버에서 응답
                        jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
                    else {
                        Log.e("MynoteCall", "jsonSteamData Not Found");
                        return null;
                    }
                    String line = "";
                    StringBuilder buf = new StringBuilder();
                    while ((line = jsonStreamData.readLine()) != null) {
                        Log.i("lineResult", line.toString());
                        buf.append(line);
                    }
                    list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리
                    //JSONObject title = list.getJSONObject("title");
                    //여기서 값을 처리



                    JSONArray img_array = new JSONArray(list.getString("img"));
                    JSONArray title_array = new JSONArray(list.getString("title"));
                    JSONArray content_array = new JSONArray(list.getString("content"));
                    //JSONArray title_array = new JSONArray(list.getString("title"));

                    Log.i("bbq",img_array.toString());
                    Log.i("bbq2",title_array.toString());
                    for(int i=0; i<title_array.length(); i++) {
                        prgmImages.add(img_array.getInt(i));
                        prgmNameList.add(title_array.getString(i));
                        subtitle.add(content_array.getString(i));
                        subtitle2.add("회원수:30");

                        //prgmImages[i] =  img_array.getInt(i);
//                        subtitle[i] = content_array.getString(i);
//                        subtitle2[i] = "회원수:30";
                    }
//                    Log.i("6565656", prgmNameList[2]);
//                    Log.i("index",subtitle[2]);
//                    Log.i("title", list.getString("title"));
//                    Log.i("abcdefghijkl", prgmImages.toString());

                } catch (IOException ioe) {
                    Log.e("MynoteCall", "IOException");
                    ioe.getStackTrace();
                } catch (JSONException jse) {
                    Log.i("MainViewPagerJsonerror", jse.toString());
                    jse.getStackTrace();
                }
                return null;
            }

            protected void onPostExecute(Integer a) {


                lv=(ListView) v.findViewById(R.id.listView2);
                lv.setAdapter(new club_list( getActivity(), prgmNameList, prgmImages, subtitle, subtitle2));

                Log.e("test", "@");
            }
        }
        BackgroundTask task = new BackgroundTask();
        task.execute(null, null, null);


        return v;
    }


    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }
}




//
//public class board_main extends Activity {
//
//    ListView lv;
//    Context context;
//
//    ArrayList prgmName;
//    public static int [] prgmImages={R.drawable.images,R.drawable.images1,R.drawable.images2,R.drawable.images3,R.drawable.images4,R.drawable.images5,R.drawable.images6,R.drawable.images7,R.drawable.images8};
//    public String [] prgmNameList= {"게시판1","게시판2","게시판3","게시판4","게시판5","게시판6","게시판7","게시판8","게시판9"};
//    public String [] subtitle = {"내용1","내용2","내용3","내용4","내용5","내용6","내용7","내용8","내용9"};
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_board_main);
//
//
//        class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
//            JSONObject list = null;
//
//
//            protected void onPreExecute() {
//
//            }
//
//            @Override
//            protected Integer doInBackground(Integer... arg0) {
//                // TODO Auto-generated method stub
//                Log.e("test", "@");
//                HttpURLConnection urlConn = null;
//                OutputStream outStream = null;
//                BufferedReader jsonStreamData = null;
//                BufferedWriter writer = null;
//                Log.e("test", "@");
//
//                try {
//
//                    Log.e("test", "@");
//                    //첫번째 부분
//                    urlConn = getHttpURLConnection("http://52.69.253.198:3001/board", "GET", getApplicationContext());
//                    int response = urlConn.getResponseCode();   //받을 권리를 받음.
//                    if (response >= 200 && response < 300)      //서버에서 응답
//                        jsonStreamData = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));   //json  내용을 받아온다.
//                    else {
//                        Log.e("MynoteCall", "jsonSteamData Not Found");
//                        return null;
//                    }
//                    String line = "";
//                    StringBuilder buf = new StringBuilder();
//                    while ((line = jsonStreamData.readLine()) != null) {
//                        Log.i("lineResult", line.toString());
//                        buf.append(line);
//                    }
//                    list = new JSONObject(buf.toString());            //json형태로 가져와서 값을 정리
//                    //JSONObject title = list.getJSONObject("title");
//                    //여기서 값을 처리
//
//
//                    JSONArray title_array = new JSONArray(list.getString("title"));
//                    JSONArray content_array = new JSONArray(list.getString("content"));
//
//
//                    for(int i=0; i<title_array.length(); i++){
//                        prgmNameList[i] = title_array.getString(i);
//                        subtitle[i] = content_array.getString(i);
//                    }
//                    Log.i("6565656", prgmNameList[2]);
//                    Log.i("index",subtitle[2]);
//                    Log.i("title", list.getString("title"));
//
//                } catch (IOException ioe) {
//                    Log.e("MynoteCall", "IOException");
//                    ioe.getStackTrace();
//                } catch (JSONException jse) {
//                    Log.i("MainViewPagerJsonerror", jse.toString());
//                    jse.getStackTrace();
//                }
//                return null;
//            }
//
//            protected void onPostExecute(Integer a) {
//                lv = (ListView) findViewById(R.id.listView);
//                lv.setAdapter(new CustomAdapter(getApplicationContext(), prgmNameList, prgmImages, subtitle));
//                Log.e("test", "@");
//            }
//        }
//        BackgroundTask task = new BackgroundTask();
//        task.execute(null, null, null);
//    }
//
//    //두번째 부분
//    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
//        HttpURLConnection httpConnetion = null;
//        try {
//            URL url = new URL(targetURL);
//            httpConnetion = (HttpURLConnection) url.openConnection();
//
//            if (reqMethod.equals("POST")) {
//                httpConnetion.setRequestMethod(reqMethod);
//                httpConnetion.setDoOutput(true);
//                Log.i("Post", "post");
//            }
//            if (reqMethod.equals("GET")) {
//                httpConnetion.setRequestMethod(reqMethod);
//                Log.e("GET", "get");
//            }
//            httpConnetion.setDoInput(true);
//            httpConnetion.setConnectTimeout(15000);
//            httpConnetion.setUseCaches(false);
//            httpConnetion.setReadTimeout(15000);
//            httpConnetion.setRequestProperty("Content-Type", "application/json");
////            httpConnetion.setRequestProperty("Accept-Encoding",
////                    "musixmatch");
//        } catch (RuntimeException e) {
//            Log.e("getHttp", "getHttp 에러 발생", e);
//
//        } catch (MalformedURLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return httpConnetion;
//    }
//
//
//    public void onButton(View v){
//        Intent intent = new Intent(getApplicationContext(),board_write.class);
//        startActivity(intent);
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//}