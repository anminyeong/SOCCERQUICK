package com.example.soccerquick2.MyClub;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soccerquick2.Board.board_info;
import com.example.soccerquick2.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import static com.example.soccerquick2.Fragment_Club.Fragment_Club_List.getHttpURLConnection;

public class club_info_list_custom extends BaseAdapter{
    List<String> title;
    List<String> sub;
    List<Integer> imageId;
    Context context;

    String image;
    String packName;

    String club_position;
    String member_id;

    private static LayoutInflater inflater=null;
    public club_info_list_custom(Context context, List<String> prgmNameList, List<Integer> prgmImages, List<String> subtitle) {
        // TODO Auto-generated constructor stub
        imageId = prgmImages;
        title=prgmNameList;
        sub = subtitle;
        this.context=context;
        //imageId=prgmImages;
        inflater = ( LayoutInflater )context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return title.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView tv;
        TextView tv2;
        ImageView img;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.activity_board_list2, null);
        holder.tv=(TextView) rowView.findViewById(R.id.textView1);
        holder.tv2=(TextView) rowView.findViewById(R.id.textView2);
        holder.img = (ImageView) rowView.findViewById(R.id.imageView1);

        holder.tv.setText(title.get(position));
        holder.tv2.setText(sub.get(position));
       // holder.img.setImageResource(imageId.get(position));



        image = "images"+ imageId.get(position);
        packName = context.getPackageName();
        int resID = context.getResources().getIdentifier(image, "drawable", packName);

        Log.e("club_list", image + "::" + resID);
        holder.img.setImageResource(resID);




        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                Intent intent = new Intent(context,club_info.class);
                intent.putExtra("club_name",title.get(position).toString());
                intent.putExtra("club_img",context.getResources().getIdentifier(image, "drawable", packName));
                intent.putExtra("club_content",sub.get(position));
                Log.i("index", title.get(position).toString());
                context.startActivity(intent);

//                Toast.makeText(context, "You Clicked "+ result.get(position), Toast.LENGTH_SHORT).show();
//
//
//                SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
//                member_id = pref.getString("id", "");
//
//                class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
//                    protected void onPreExecute() {
//                        club_position = result.get(position).toString();
//
//                    }
//
//                    @Override
//                    protected Integer doInBackground(Integer... arg0) {
//                        // TODO Auto-generated method stub
//                        Log.e("test","@");
//                        HttpURLConnection urlConn = null;
//                        OutputStream outStream = null;
//
//                        BufferedWriter writer = null;
//                        Log.e("test", "@");
//
//                        try {
//                            //jsonText/
//                            JSONObject jsonBody = new JSONObject();
//                            jsonBody.put("title", club_position);
//
//                            //jsonBody.put("member_id", member_id); 멤버 아이디
//
//                            Log.i("jsonBody", jsonBody.toString());
//                            Log.e("test", "@");
//                            //url 수정 해야 한다.
//                            urlConn = getHttpURLConnection("http://52.193.2.122:3001/clubdetail/"+member_id, "POST", context);
//                            //int response = urlConn.getResponseCode();
//                            //String reString = urlConn.getRequestMethod();
//                            //urlConn.getRequestProperty("application/json");
//                            outStream = urlConn.getOutputStream();
//                            Log.e("test","@");
//                            writer = new BufferedWriter(new OutputStreamWriter(outStream,"UTF-8"));
//                            StringBuilder buf = new StringBuilder();
//                            buf.append(jsonBody.toString());
//                            writer.write(buf.toString());
//
//                            Log.i("OutStream", outStream.toString());
//                            writer.flush();
//                            Log.i("inputStream", urlConn.getResponseCode() + "");
//
//                            InputStream inputstream = urlConn.getInputStream();
//
//                            writer.close();
//                            outStream.close();
//
//                        } catch (JSONException joe) {
//                            Log.e("Group_Page_PostResult", "IOException");
//                            joe.getStackTrace();
//                        } catch (IOException e) {
//                            // TODO Auto-generated catch block
//                            e.printStackTrace();
//                        } finally {
//                            if(urlConn != null){
//
//                                urlConn.disconnect();
//                            }
//                        }
//                        return null;
//                    }
//                    protected void onPostExecute(Integer a) {
////                        Toast.makeText(getApplicationContext(), "글쓰기성공", Toast.LENGTH_LONG).show();
//                        Intent intent = new Intent(context,club_info.class);
//                        context.startActivity(intent);
//                    }
//                }new BackgroundTask().execute();


            }
        });
        return rowView;
    }
//
//    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
//        HttpURLConnection httpConnetion = null;
//        try {
//            URL url = new URL(targetURL);
//            httpConnetion = (HttpURLConnection) url.openConnection();
//
//            if (reqMethod.equals("POST")) {
//                httpConnetion.setRequestMethod(reqMethod);
//                httpConnetion.setDoOutput(true);
//                Log.i("Post", "post");
//            }
//            if (reqMethod.equals("GET")) {
//                httpConnetion.setRequestMethod(reqMethod);
//                Log.e("GET", "get");
//            }
//            httpConnetion.setDoInput(true);
//            httpConnetion.setConnectTimeout(15000);
//            httpConnetion.setUseCaches(false);
//            httpConnetion.setReadTimeout(15000);
//            httpConnetion.setRequestProperty("Content-Type", "application/json");
////            httpConnetion.setRequestProperty("Accept-Encoding",
////                    "musixmatch");
//        } catch (RuntimeException e) {
//            Log.e("getHttp", "getHttp 에러 발생", e);
//
//        } catch (MalformedURLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return httpConnetion;
//    }

}