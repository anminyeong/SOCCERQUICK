package com.example.soccerquick2.Board;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.soccerquick2.Fragment_Club.club_tab;
import com.example.soccerquick2.Match.match_list;
import com.example.soccerquick2.R;
import com.example.soccerquick2.ground.Ground;
import com.example.soccerquick2.user_info;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;


public class board_write extends Activity {

    private String[] navItems = {"매치현황", "구장현황", "MyClub",
            "게시판", "회원정보 수정","로그아웃"};
    private ListView lvNavList;
    private String board_head, board_title, board_content; //말머리 변수
    private TextView title, content;
    SimpleDateFormat curDate = new SimpleDateFormat("yyyy/MM/dd"); //현재시간
    String cur_date = curDate.format(new Date(System.currentTimeMillis()));

    String member_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board_write);


        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        member_id = pref.getString("id", "");


        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.item_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        title = (TextView)findViewById(R.id.editText); //제목
        content = (TextView)findViewById(R.id.editText2); //내용

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                board_head = adapterView.getItemAtPosition(i).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        Button btn = (Button)findViewById(R.id.writeBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("test", "@");
                //post 부분
                class BackgroundTask extends AsyncTask<Integer, Integer, Integer> {
                    protected void onPreExecute() {
                        board_title = title.getText().toString();
                        board_content = content.getText().toString();
                    }

                    @Override
                    protected Integer doInBackground(Integer... arg0) {
                        // TODO Auto-generated method stub
                        Log.e("test","@");
                        HttpURLConnection urlConn = null;
                        OutputStream outStream = null;

                        BufferedWriter writer = null;
                        Log.e("test", "@");

                        try {
                            //jsonText/
                            JSONObject jsonBody = new JSONObject();
                            jsonBody.put("title", board_title);
                            jsonBody.put("content", board_content);
                            jsonBody.put("header", board_head);
                            jsonBody.put("date", cur_date);
                            jsonBody.put("type",1);
                            jsonBody.put("member_id", member_id);

                            Log.i("jsonBody", jsonBody.toString());
                            Log.e("test", "@");
                            //url 수정 해야 한다.
                            urlConn = getHttpURLConnection("http://52.69.253.198:3001/board/upload/"+member_id, "POST", getApplicationContext());
                            //int response = urlConn.getResponseCode();
                            //String reString = urlConn.getRequestMethod();
                            //urlConn.getRequestProperty("application/json");
                            outStream = urlConn.getOutputStream();
                            Log.e("test","@");
                            writer = new BufferedWriter(new OutputStreamWriter(outStream,"UTF-8"));
                            StringBuilder buf = new StringBuilder();
                            buf.append(jsonBody.toString());
                            writer.write(buf.toString());

                            Log.i("OutStream", outStream.toString());
                            writer.flush();
                            Log.i("inputStream", urlConn.getResponseCode() + "");

                            InputStream inputstream = urlConn.getInputStream();

                            writer.close();
                            outStream.close();

                        } catch (JSONException joe) {
                            Log.e("Group_Page_PostResult", "IOException");
                            joe.getStackTrace();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } finally {
                            if(urlConn != null){

                                urlConn.disconnect();
                            }
                        }
                        return null;
                    }
                    protected void onPostExecute(Integer a) {
                        Toast.makeText(getApplicationContext(), "글쓰기성공", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), board_main.class);
                        startActivity(intent);
                    }
                }new BackgroundTask().execute();
            }
        });

        btn = (Button)findViewById(R.id.cancelBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),board_main.class);
                startActivity(intent);
            }
        });

        //메뉴 리스트뷰
        lvNavList = (ListView) findViewById(R.id.lv_activity_main_nav_list);
        lvNavList.setAdapter(
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lvNavList.setOnItemClickListener(new DrawerItemClickListener());
    }

    //메뉴 클래스
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
            Intent intent;
            switch (position) {
                case 0:
                    intent = new Intent(getApplicationContext(), match_list.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(getApplicationContext(), Ground.class);
                    startActivity(intent);
                    break;
                case 2:
                    intent = new Intent(getApplicationContext(), club_tab.class);
                    startActivity(intent);
                    break;
                case 3:
                    intent = new Intent(getApplicationContext(), board_main.class);
                    startActivity(intent);
                    break;
                case 4:
                    intent = new Intent(getApplicationContext(), user_info.class);
                    startActivity(intent);
                    break;
                case 5:
                    //로그아웃
                    break;
            }
        }
    }
    //2번째
    public static HttpURLConnection getHttpURLConnection(String targetURL, String reqMethod, Context context) {
        HttpURLConnection httpConnetion = null;
        try {
            URL url = new URL(targetURL);
            httpConnetion = (HttpURLConnection) url.openConnection();

            if (reqMethod.equals("POST")) {
                httpConnetion.setRequestMethod(reqMethod);
                httpConnetion.setDoOutput(true);
                Log.i("Post", "post");
            }
            if (reqMethod.equals("GET")) {
                httpConnetion.setRequestMethod(reqMethod);
                Log.e("GET", "get");
            }
            httpConnetion.setDoInput(true);
            httpConnetion.setConnectTimeout(15000);
            httpConnetion.setUseCaches(false);
            httpConnetion.setReadTimeout(15000);
            httpConnetion.setRequestProperty("Content-Type", "application/json");
//            httpConnetion.setRequestProperty("Accept-Encoding",
//                    "musixmatch");
        } catch (RuntimeException e) {
            Log.e("getHttp", "getHttp 에러 발생", e);

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return httpConnetion;
    }

}
